(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ 100:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 50:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(51);
/* harmony import */ var core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(67);
/* harmony import */ var core_js_modules_es_array_filter__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_for_each__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(70);
/* harmony import */ var core_js_modules_es_array_for_each__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_for_each__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_includes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72);
/* harmony import */ var core_js_modules_es_array_includes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(78);
/* harmony import */ var core_js_modules_es_object_to_string__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_exec__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45);
/* harmony import */ var core_js_modules_es_regexp_exec__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_to_string__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(82);
/* harmony import */ var core_js_modules_es_regexp_to_string__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_string_includes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(83);
/* harmony import */ var core_js_modules_es_string_includes__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_replace__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(87);
/* harmony import */ var core_js_modules_es_string_replace__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(92);
/* harmony import */ var core_js_modules_web_dom_collections_for_each__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(26);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(47);
/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(48);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var lazysizes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(94);
/* harmony import */ var lazysizes__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lazysizes__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var papaparse__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(49);
/* harmony import */ var papaparse__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(papaparse__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _css_normalize_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(95);
/* harmony import */ var _css_normalize_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_css_normalize_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _css_postmedia_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(96);
/* harmony import */ var _css_postmedia_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_css_postmedia_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _css_colors_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(97);
/* harmony import */ var _css_colors_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_css_colors_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _css_fonts_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(98);
/* harmony import */ var _css_fonts_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_css_fonts_css__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _css_main_css__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(99);
/* harmony import */ var _css_main_css__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_css_main_css__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _css_nav_css__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(100);
/* harmony import */ var _css_nav_css__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_css_nav_css__WEBPACK_IMPORTED_MODULE_20__);













// LIBS

 // CSS






 // VARS

var headerOffset = 50;
var bignumURL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSoEwt95_sCck6DtZAZIA1SLflANuwvGgQLtQEIYO0x7eOa1pQ-yKQZO8W-FdFDKx3abnITsxcqEpeD/pub?gid=440911543&single=true&output=csv'; // JS

var init = /*#__PURE__*/function () {
  var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_12___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_10___default.a.mark(function _callee() {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_10___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            console.log('init!'); // nav menu

            setupMenu(); // fetch data & update big numbers section

            papaparse__WEBPACK_IMPORTED_MODULE_14__["parse"](bignumURL, {
              download: true,
              header: false,
              complete: function complete(results) {
                setupBigNums(results.data);
              }
            });

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function init() {
    return _ref.apply(this, arguments);
  };
}();

function setupBigNums(data) {
  console.log(data);
  var main = document.getElementById('main-big-num');
  var drug = document.getElementById('drugs-big-num');
  var timestamp = document.createElement('p');
  var mainDiv = document.createElement('div');
  var drugDiv = document.createElement('div');
  mainDiv.className = 'stat-box';
  drugDiv.className = 'stat-box';
  timestamp.className = 'timestamp'; // build main big num section

  var new_deaths = data.filter(function (array) {
    return array.includes('deaths_new');
  });
  var total_deaths = data.filter(function (array) {
    return array.includes('deaths_total');
  });
  var daily_deaths = data.filter(function (array) {
    return array.includes('deaths_daily');
  });
  var last_update = data.filter(function (array) {
    return array.includes('last_update');
  });
  mainDiv.innerHTML = "\n\t\t<div class=\"stat\">\n\t\t\t<p class=\"big-num\">".concat(new_deaths[0][1], "</p>\n\t\t\t<p class=\"label\">New deaths since last update</p>\n\t\t</div>\n\t\t<div class=\"stat\">\n\t\t\t<p class=\"big-num\">").concat(numberWithCommas(total_deaths[0][1]), "</p>\n\t\t\t<p class=\"label\">Deaths <br/> since 2016</p>\n\t\t</div>\n\t\t<div class=\"stat\">\n\t\t\t<p class=\"big-num\">").concat(daily_deaths[0][1], "</p>\n\t\t\t<p class=\"label\">Average deaths per day</p>\n\t\t</div>\n\t");
  timestamp.innerHTML = "Last update: ".concat(last_update[0][1]);
  main.appendChild(mainDiv);
  main.appendChild(timestamp); // build drugs big num section

  var fenty_deaths = data.filter(function (array) {
    return array.includes('deaths_fentanyl');
  });
  var benzo_deaths = data.filter(function (array) {
    return array.includes('deaths_benzo');
  });
  drugDiv.innerHTML = "\n\t\t<div class=\"stat\">\n\t\t\t<p class=\"big-num\">".concat(benzo_deaths[0][1], "</p>\n\t\t\t<p class=\"label\">Deaths involving benzodiazepines</p>\n\t\t</div>\n\t\t<div class=\"stat\">\n\t\t\t<p class=\"big-num\">").concat(fenty_deaths[0][1], "</p>\n\t\t\t<p class=\"label\">Deaths invovlving extreme fentanyl concentrations</p>\n\t\t</div>\n\t");
  drug.appendChild(drugDiv);
}

function setupMenu() {
  document.querySelectorAll('.nav-li a[href^="#"').forEach(function (trigger) {
    trigger.onclick = function (e) {
      e.preventDefault();
      var hash = this.getAttribute('href');
      var target = document.querySelector(hash);
      var elementPosition = target.offsetTop;
      var offsetPosition = elementPosition - headerOffset; // reset highlight

      document.querySelectorAll('.nav-li').forEach(function (li) {
        li.className = 'nav-li';
      });
      var parent = this.parentNode;
      parent.className = 'nav-li active-nav'; // scroll page

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    };
  });
}

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

init();

/***/ }),

/***/ 95:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 96:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 97:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 98:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 99:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

},[[50,1,2]]]);